<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Gruppa;
use App\Models\GruppaUser;
use App\Models\User;
use Illuminate\Http\Request;

class GroupController extends Controller
{
    
}
